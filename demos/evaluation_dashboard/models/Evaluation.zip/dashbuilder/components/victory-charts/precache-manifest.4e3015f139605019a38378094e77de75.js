self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5391ed21653b9adbc7ab4f317384d588",
    "url": "./index.html"
  },
  {
    "revision": "b533307a0316704b1232",
    "url": "./static/css/2.6618b920.chunk.css"
  },
  {
    "revision": "2bedf8d32f56240af59f",
    "url": "./static/css/main.27fd15f6.chunk.css"
  },
  {
    "revision": "b533307a0316704b1232",
    "url": "./static/js/2.f48632cc.chunk.js"
  },
  {
    "revision": "64bea2e190f27355a76963b8cb94bb7b",
    "url": "./static/js/2.f48632cc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2bedf8d32f56240af59f",
    "url": "./static/js/main.09548925.chunk.js"
  },
  {
    "revision": "11230c25051c3ba8f98c",
    "url": "./static/js/runtime-main.27fc2337.js"
  }
]);