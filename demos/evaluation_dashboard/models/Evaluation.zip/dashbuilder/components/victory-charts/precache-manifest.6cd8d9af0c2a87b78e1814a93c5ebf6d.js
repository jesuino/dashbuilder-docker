self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8038e2c04ad980508758b6b8a60db0b5",
    "url": "./index.html"
  },
  {
    "revision": "e3992c79e194929c2e7a",
    "url": "./static/css/2.6618b920.chunk.css"
  },
  {
    "revision": "53ac123282b5a123e058",
    "url": "./static/css/main.27fd15f6.chunk.css"
  },
  {
    "revision": "e3992c79e194929c2e7a",
    "url": "./static/js/2.a30a7d64.chunk.js"
  },
  {
    "revision": "64bea2e190f27355a76963b8cb94bb7b",
    "url": "./static/js/2.a30a7d64.chunk.js.LICENSE.txt"
  },
  {
    "revision": "53ac123282b5a123e058",
    "url": "./static/js/main.157749d8.chunk.js"
  },
  {
    "revision": "11230c25051c3ba8f98c",
    "url": "./static/js/runtime-main.27fc2337.js"
  }
]);