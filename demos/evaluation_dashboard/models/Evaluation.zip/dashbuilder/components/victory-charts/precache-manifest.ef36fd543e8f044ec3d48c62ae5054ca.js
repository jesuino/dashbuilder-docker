self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "525d0a5bd885eee692256eb80c1f341c",
    "url": "./index.html"
  },
  {
    "revision": "b533307a0316704b1232",
    "url": "./static/css/2.6618b920.chunk.css"
  },
  {
    "revision": "c8ff7d3c0be5c28fe59c",
    "url": "./static/css/main.27fd15f6.chunk.css"
  },
  {
    "revision": "b533307a0316704b1232",
    "url": "./static/js/2.f48632cc.chunk.js"
  },
  {
    "revision": "64bea2e190f27355a76963b8cb94bb7b",
    "url": "./static/js/2.f48632cc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c8ff7d3c0be5c28fe59c",
    "url": "./static/js/main.683302da.chunk.js"
  },
  {
    "revision": "11230c25051c3ba8f98c",
    "url": "./static/js/runtime-main.27fc2337.js"
  }
]);