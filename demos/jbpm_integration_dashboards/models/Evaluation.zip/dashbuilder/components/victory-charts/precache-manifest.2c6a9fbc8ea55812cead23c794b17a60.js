self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "07af9ed38518678d574b0a97b4b99a31",
    "url": "./index.html"
  },
  {
    "revision": "b533307a0316704b1232",
    "url": "./static/css/2.6618b920.chunk.css"
  },
  {
    "revision": "88aab6eaabab81936186",
    "url": "./static/css/main.27fd15f6.chunk.css"
  },
  {
    "revision": "b533307a0316704b1232",
    "url": "./static/js/2.f48632cc.chunk.js"
  },
  {
    "revision": "64bea2e190f27355a76963b8cb94bb7b",
    "url": "./static/js/2.f48632cc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "88aab6eaabab81936186",
    "url": "./static/js/main.1e749817.chunk.js"
  },
  {
    "revision": "11230c25051c3ba8f98c",
    "url": "./static/js/runtime-main.27fc2337.js"
  }
]);