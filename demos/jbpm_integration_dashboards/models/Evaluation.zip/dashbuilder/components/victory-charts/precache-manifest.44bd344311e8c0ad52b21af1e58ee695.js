self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bb2b2a952da3af03c6ab1718d3f30d68",
    "url": "./index.html"
  },
  {
    "revision": "83ea23a10527375ad2a4",
    "url": "./static/css/2.6618b920.chunk.css"
  },
  {
    "revision": "15d111bee1fa4f7bfb09",
    "url": "./static/css/main.27fd15f6.chunk.css"
  },
  {
    "revision": "83ea23a10527375ad2a4",
    "url": "./static/js/2.da1eef36.chunk.js"
  },
  {
    "revision": "64bea2e190f27355a76963b8cb94bb7b",
    "url": "./static/js/2.da1eef36.chunk.js.LICENSE.txt"
  },
  {
    "revision": "15d111bee1fa4f7bfb09",
    "url": "./static/js/main.c46d916a.chunk.js"
  },
  {
    "revision": "11230c25051c3ba8f98c",
    "url": "./static/js/runtime-main.27fc2337.js"
  }
]);