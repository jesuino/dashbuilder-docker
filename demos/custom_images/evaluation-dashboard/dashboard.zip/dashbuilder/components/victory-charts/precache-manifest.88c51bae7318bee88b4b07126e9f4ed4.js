self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "199dc55a94a41794dd0715a2eebcf6e1",
    "url": "./index.html"
  },
  {
    "revision": "fb3d4b3c54b6a0d414ff",
    "url": "./static/css/2.6618b920.chunk.css"
  },
  {
    "revision": "57f72e8ebf4fb2fb736b",
    "url": "./static/css/main.27fd15f6.chunk.css"
  },
  {
    "revision": "fb3d4b3c54b6a0d414ff",
    "url": "./static/js/2.2b1dde9b.chunk.js"
  },
  {
    "revision": "64bea2e190f27355a76963b8cb94bb7b",
    "url": "./static/js/2.2b1dde9b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "57f72e8ebf4fb2fb736b",
    "url": "./static/js/main.e797d792.chunk.js"
  },
  {
    "revision": "11230c25051c3ba8f98c",
    "url": "./static/js/runtime-main.27fc2337.js"
  }
]);