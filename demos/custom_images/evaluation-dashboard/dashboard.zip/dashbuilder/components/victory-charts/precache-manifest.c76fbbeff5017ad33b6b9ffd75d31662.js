self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "54c0e1b0ecdc6dcb29abcd7c2d19aaa8",
    "url": "./index.html"
  },
  {
    "revision": "b533307a0316704b1232",
    "url": "./static/css/2.6618b920.chunk.css"
  },
  {
    "revision": "45a440ff8534dbbdcaa8",
    "url": "./static/css/main.27fd15f6.chunk.css"
  },
  {
    "revision": "b533307a0316704b1232",
    "url": "./static/js/2.f48632cc.chunk.js"
  },
  {
    "revision": "64bea2e190f27355a76963b8cb94bb7b",
    "url": "./static/js/2.f48632cc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "45a440ff8534dbbdcaa8",
    "url": "./static/js/main.12d3d643.chunk.js"
  },
  {
    "revision": "11230c25051c3ba8f98c",
    "url": "./static/js/runtime-main.27fc2337.js"
  }
]);